package enumerations;

public enum Bathmida {
Lecturer,
Assistant,
Associate,
Professor
}

