package mainPacket;

import enumerations.StaffType;
import exceptions.InvalidWorkingHours;
import randomize.Randomize;
import employees.*;
public class MainClass {
	public static void main(String[] args) throws InvalidWorkingHours{
		System.out.println("HELLO PROJECT WEEK 4");
		try {createRandomizedEmployees(100);}
		catch(InvalidWorkingHours e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void createRandomizedEmployees(int k) throws InvalidWorkingHours {
		System.out.println("Creating "+ k +" Randomized Employees");
		for(int i=1; i<=k; i++) {
			StaffType staff = Randomize.Staff();
			if (staff==StaffType.Permanent) {
				PermanentStaff pstaff = new PermanentStaff(i);
				pstaff.CalculateMonthlySalary();
				pstaff.printInfo();
			}
			
			if (staff==StaffType.HourlyBased) {
				HourlyBasedStaff hstaff = new HourlyBasedStaff(i);
				if(hstaff.getworkedHours()>40) {
					throw new InvalidWorkingHours("Invalid worked hours for employee "+hstaff.getEmployeeID());
				}
				hstaff.CalculateMonthlySalary();
				hstaff.printInfo();
				}
				
			}
			
		}
}


