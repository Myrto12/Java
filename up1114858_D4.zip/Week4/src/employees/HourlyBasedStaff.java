package employees;
import enumerations.WorkingExperience;
import exceptions.InvalidWorkingHours;
import randomize.Randomize;

public class HourlyBasedStaff extends Academic {
		private WorkingExperience experience;
		private int workedHours;
		private int monthlysalary;
		
		public HourlyBasedStaff(int id) {
			super(id);
			experience=Randomize.WorkingExperience();
			workedHours=Randomize.MonthlyWorkingHours();
		}
		
		@Override public int CalculateMonthlySalary() {
			int hourlySalary=0;
			if(experience==WorkingExperience.uptoFiveYears) hourlySalary=10;
			if(experience==WorkingExperience.FiveToTenYears) hourlySalary=20;
			if(experience==WorkingExperience.morethanTenYears) hourlySalary=30;
			monthlysalary = baseMonthlySalary+hourlySalary*workedHours;
			return monthlysalary;

		}
		public int getworkedHours() {return workedHours;} 
		
		public void printInfo() {
			System.out.println("");
			System.out.println("EmployeeID:"+super.getEmployeeID()+ " is hourly based.");
			System.out.println("WorkingExperience:"+experience);
			System.out.println("WorkedHours:"+workedHours);
			System.out.println("Hourly based employee salary:" +monthlysalary);
		}
		public void setworkedhours(int hours) throws InvalidWorkingHours {
			if(hours>40) {
				throw new InvalidWorkingHours("Working hours must be less than 40");
			}
			else {
				this.workedHours=hours;
			}
		}
			
}
	


