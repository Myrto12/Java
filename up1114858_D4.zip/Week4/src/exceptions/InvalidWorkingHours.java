package exceptions;

public class InvalidWorkingHours extends Exception{
	public InvalidWorkingHours(String str) {
		super(str);
	}
}
