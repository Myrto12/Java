package twoDimensionalShape;
import basicElements.*;

public class Circle {
	private Point circleCenter; 
	private double radius=1.0;
	
	 public Circle(Point point,double Radius){
		circleCenter=point;
		radius=Radius;
	}

	
	 public double getArea(){
		   return radius*radius*3.14159;
		}
}
