package twoDimensionalShape;
import basicElements.Point;

public class Rectangle { // public
	private Point pLeftDownCorner; //private//
	private double width,height=0;
	public Rectangle(Point point,double w, double h){ //public
		pLeftDownCorner=point;
		width=w;
		height=h;
	}
	public double getArea() {
		return width*height;		
	}
	
}
