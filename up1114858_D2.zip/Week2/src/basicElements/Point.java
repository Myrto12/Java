package basicElements;

public class Point {
	private int xcoords;
	private int ycoords;
	public Point(int x, int y){ 
		xcoords=x;
		ycoords=y;
		
	}

}
