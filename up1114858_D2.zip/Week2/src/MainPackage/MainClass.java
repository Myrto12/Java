package MainPackage;

import java.util.Scanner;
import basicElements.*;
import twoDimensionalShape.*;

public class MainClass {
	public static void main(String[] args) {		
		System.out.println("Please enter point coordinates x,y");
		Scanner scanner = new Scanner(System.in);
		int x = scanner.nextInt();
		int y = scanner.nextInt();
		Point p = new Point(x,y);
		
		System.out.println("Do you want to create a Rectangle or a Circle?");
		scanner.nextLine();  
		String option = scanner.nextLine();
		if(option.equals("Rectangle")) {
			System.out.println("Please enter width, height");
			double w = scanner.nextDouble();
			double h = scanner.nextDouble();
			Rectangle Rect = new Rectangle(p,w,h);
			System.out.println("Area of Rectangle:"+Rect.getArea());
		}
		else if(option.equals("Circle")) {
			System.out.println("Please enter radius");
			double r = scanner.nextDouble();
			Circle Cir = new Circle(p,r);
			System.out.println("Area of Circle:"+Cir.getArea());
		}
		else {
			System.out.println("Invalid input, please enter one of the option above!");
		}
		scanner.close();
	}

}



