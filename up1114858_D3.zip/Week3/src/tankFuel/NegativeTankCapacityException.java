package tankFuel;

public class NegativeTankCapacityException extends Exception {
	public NegativeTankCapacityException (String str) {
		super(str);
	}

}
