package tankFuel;

public class InvalidFuelTempoException extends Exception{
	public InvalidFuelTempoException (String str) {
		super(str);
	}

}
