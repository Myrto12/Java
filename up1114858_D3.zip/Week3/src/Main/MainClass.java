package Main;
import tankFuel.*;

public class MainClass {
	public static void main (String[] args) {
        TankFuel myTank = null;
        boolean fillTank=true; 
		try {
		myTank = new TankFuel(50);
		}
		catch (NegativeTankCapacityException ex) {
			fillTank=false;
			System.out.println(ex.getMessage());
		}
		
		double fuelTempo=0.1;
		while(fillTank) {
			try {
				myTank.fuelTank(fuelTempo);
			}
			catch (InvalidFuelTempoException ex) {
				fillTank=false;
				System.out.println(ex.getMessage());
			} 
			catch (TankFullException ex) {fillTank=false;}

		}
		if(myTank!=null) {
			System.out.println(myTank.getTankFuel());
		}
		/*fuelTempo=0.2;                                 //kwdikas gia ton elegxo ths swsths leitourgias ths TankFullException
		try {
			myTank.fuelTank(fuelTempo);
		} catch (InvalidFuelTempoException | TankFullException ex) {
			fillTank=false;
			System.out.println(ex.getMessage());
		}*/
		myTank=null;
	}

}
