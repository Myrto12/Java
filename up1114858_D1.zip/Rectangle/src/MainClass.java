public class MainClass {
	public static void main(String[] args) {
		Rectangle objRect=new Rectangle(1.0f,2.0f,3.0f,5.0f);
		objRect.contains(3,5);
		Rectangle.printCounter();
		Rectangle objRect2=new Rectangle(1.0f,6.0f,3.0f,5.0f);
		objRect2.contains(3, 5);
		Rectangle.printCounter();
	}

}
