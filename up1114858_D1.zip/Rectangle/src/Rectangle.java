
public class Rectangle {
	private float x=0;
	private float y=0;
	private float width, height=0;
	public static int counter;

	
	Rectangle(float px, float py,float w, float h){ //constructor//
		x=px;
		y=py;
		width=w;
		height=h;
		counter++; //diathesimo apo ton constructor poy den einai static//
	}

	public boolean contains(float sx, float sy) {
		boolean res=false;
		if(x<=sx && sx<=x + width && y<=sy && sy<=y + height) {
			res=true;
			System.out.println("IN");
		}
		else {
			System.out.println("OUT");
		}
		return res;
	}
	
	static void printCounter() {
		System.out.println(counter);
	}
}
