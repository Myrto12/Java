import java.util.Scanner;
public class Week1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter x, y, width, height");
		int x = input.nextInt();
		int y = input.nextInt();
		int w = input.nextInt();
		int h = input.nextInt();
		
		Rectangle objRect = new Rectangle(x,y,w,h);
		System.out.println("Enter coordinates sx,sy");
		int sx = input.nextInt();
		int sy = input.nextInt();
		input.close();
		
		objRect.contains(sx, sy);
	}

}
