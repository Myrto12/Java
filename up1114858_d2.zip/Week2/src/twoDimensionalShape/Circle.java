package twoDimensionalShape;
import basicElements.*;

public class Circle {
	private Point cicleCenter; //public
	private double radius=1.0; //private//
	
	 public Circle(Point point,double Radius){
		cicleCenter=point;
		radius=Radius;
	}

	
	 public double getArea(){ //public h protected
		   return radius*radius*3.14159;
		}
}
