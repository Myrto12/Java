package basicElements;

public class Point {
	int xcoords;
	int ycoords;
	public Point(int x, int y){ //public
		xcoords=x;
		ycoords=y;
		
	}

}
